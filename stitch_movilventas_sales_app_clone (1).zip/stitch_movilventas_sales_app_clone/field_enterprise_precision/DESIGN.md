---
name: Field Enterprise Precision
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#3f4850'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#707881'
  outline-variant: '#bfc7d2'
  surface-tint: '#006398'
  primary: '#006194'
  on-primary: '#ffffff'
  primary-container: '#007bb9'
  on-primary-container: '#fdfcff'
  inverse-primary: '#93ccff'
  secondary: '#515d84'
  on-secondary: '#ffffff'
  secondary-container: '#c4d0fd'
  on-secondary-container: '#4c587f'
  tertiary: '#006947'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855b'
  on-tertiary-container: '#f5fff6'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cce5ff'
  primary-fixed-dim: '#93ccff'
  on-primary-fixed: '#001d31'
  on-primary-fixed-variant: '#004b73'
  secondary-fixed: '#dbe1ff'
  secondary-fixed-dim: '#b9c5f2'
  on-secondary-fixed: '#0b1a3d'
  on-secondary-fixed-variant: '#39456b'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  data-metric:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system targets commercial field agents, route delivery drivers, and field collections managers who operate under fast-paced, high-sunlight, and offline-first mobile conditions. 

The aesthetic is **Corporate Modern with high-speed utility**: crisp, purposeful, and structured. It eliminates visual noise to prioritize legibility of financial figures, customer route sequencing, real-time inventory counts, and ERP sync status. The emotional response is one of absolute operational reliability, trust, and speed—instilling confidence when closing transactions, taking signatures, or collecting payments on the road.

## Colors

The palette directly anchors to the enterprise identity with strategic semantic accents for high-stakes field tasks:

- **Primary (`#0284c7`)**: Energetic sky blue utilized for dominant interactive triggers, active tab states, and primary touch targets.
- **Secondary / Deep Corporate (`#0d1b3e`)**: Dense midnight navy, serving as the high-contrast structural anchor for app headers, persistent navigation bars, and critical metric labels.
- **Tertiary / Success (`#10b981`)**: Vivid emerald green reserved for offline-to-cloud synchronization indicators, approved collections, completed route visits, and balance receipts.
- **Alert / Warning (`#f59e0b`)**: Warm amber for pending ERP sync queue items, overdue accounts receivable, and credit ceiling warnings.
- **Error / Void (`#ef4444`)**: Crisp crimson for failed syncs, rejected checks, and stock shortages.
- **Backgrounds & Neutrals**: Pure canvas white (`#ffffff`) for cards, layered over an ultra-clean cool neutral surface (`#f8fafc`) to sustain separation without eye strain under outdoor sunlight.

## Typography

Plus Jakarta Sans delivers geometric clarity and legible apertures, essential for quick glanceability while walking or driving route stops.

- **Data Metric Level**: Added specifically for monetary figures, invoices, and remaining stock, ensuring instant legibility without mistaking glyphs.
- **Hierarchical Discipline**: Section titles are kept tight to conserve vertical viewport space on ruggedized mobile handsets.
- **Tabular Figures**: Numeric outputs across order summaries and collections must use tabular figures (`font-variant-numeric: tabular-nums`) to preserve column alignment across varying currency amounts.

## Layout & Spacing

A compact, touch-optimized fluid layout model tuned for 360px–430px mobile viewports.

- **Grid & Margins**: Default outer margin is fixed at `1rem` (16px), retaining maximum screen real estate for list items, product catalogs, and order matrices.
- **Rhythm**: Spacing uses a base-4 grid with compact micro-steps (`space-xs: 4px`, `space-sm: 8px`, `space-md: 12px`, `space-lg: 16px`, `space-xl: 24px`).
- **Touch Ergonomics**: All interactive tap regions must conform to a minimum bounding box of 48x48px, even when visually styled as compact chips or segmented pills.
- **Fixed Action Bar**: Critical transactional flows (Confirm Order, Print Receipt, Record Payment) utilize a persistent bottom docking area with `space-md` safe inset buffers.

## Elevation & Depth

Visual hierarchy uses a refined hybrid of subtle ambient drop shadows and low-contrast perimeter strokes, resisting washed-out displays in bright outdoor glare.

- **Level 0 (Canvas)**: Background surface in `#f8fafc`.
- **Level 1 (Cards, Modules, List Items)**: Surface `#ffffff` supported by a soft dual shadow: `0 1px 3px rgba(13, 27, 62, 0.05), 0 1px 2px rgba(13, 27, 62, 0.03)` combined with a crisp `1px solid #e2e8f0` border.
- **Level 2 (Modals, Slide-over Sheets, ERP Sync Drawers)**: Surface `#ffffff` accompanied by `0 10px 25px -5px rgba(13, 27, 62, 0.12), 0 8px 10px -6px rgba(13, 27, 62, 0.08)`.
- **Level 3 (Floating Sync Bubble & Floating Actions)**: `0 14px 28px rgba(2, 132, 199, 0.25)`.

## Shapes

The design system adopts roundedness level `2` (8px base corner radius) with selective full-radius pill styling for statuses and micro-actions.

- **Cards & Data Containers**: 8px (`rounded-md` / level 2 base) to preserve structured data density and maximize interior usable area.
- **Buttons & Input Elements**: 8px corner radius for a balanced, modern, yet utilitarian industrial form.
- **Status Badges & Sync Chips**: Pill-shaped (`rounded-full` / 9999px) to contrast immediately with the rectilinear geometry of transaction cards.

## Components

### Buttons
- **Primary Action**: Solid `#0284c7` background, white label, 48px height, 8px radius, subtle active scale press feedback (`transform: scale(0.98)`).
- **Secondary Action**: `#0d1b3e` background with white label for authoritative confirmations (e.g., "Transmit to ERP").
- **Ghost / Tertiary**: Subtle transparent fill with `#0284c7` text, for secondary list interactions (e.g., "Add SKU detail").

### Badges & Status Indicators
- **ERP Sync Online**: Pill container with light green background (`#ecfdf5`), `#065f46` text, with an active pulsating emerald dot indicator.
- **ERP Sync Offline / Queued**: Amber tinted badge (`#fffbeb`) with `#92400e` text, displaying queue count (e.g., `3 pendientes`).
- **Payment & Order States**: Distinct color pairs (`#ecfdf5` for "Cobrado", `#eff6ff` for "En Ruta", `#fef2f2` for "Vencido").

### Input Fields & Steppers
- **Fast-entry Inputs**: Clean 44px height inputs with `#f8fafc` background, crisp 1px `#cbd5e1` outline, focused ring in `#0284c7` (2px).
- **Numeric Stepper (SKU Quantities)**: Integrated increment/decrement block with solid touch targets (+ / - buttons at minimum 44x44px) surrounding bold centered tabular text.

### Cards & Route Lists
- **Client Route Card**: White background, 8px radius, left edge accent bar indicating visit status (green = completed, blue = next stop, gray = pending). Contains customer business name, credit limit progress bar, and rapid phone/maps callout icons.

### Sync Drawer & Banner
- Persistent top-strip offline status bar that transitions smoothly from deep navy to bright amber or emerald depending on live socket connectivity to central SAP/ERP backend.